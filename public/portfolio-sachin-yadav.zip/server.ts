import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { RESUME_PDF_BASE64 } from './src/data/resumePdfData';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// In-Memory MongoDB-style Document Store
interface MessageDocument {
  _id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
  read: boolean;
}

const db = {
  profile: {
    name: "Sachin Yadav",
    role: "Full Stack Developer",
    location: "Surat, Gujarat, India",
    phone: "+91 7822900241",
    email: "yadavsachin7249407392@gmail.com",
    linkedin: "https://linkedin.com/in/sachin-yadav-20a79b231",
    github: "https://github.com/SachinYadav2002",
    portfolioUrl: "https://sachinyadav2002.vercel.app",
    summary: "Results-driven Full Stack Developer with expertise in building scalable, high-performance web applications using React.js, Next.js, TypeScript, Node.js, Express.js, and MongoDB. Proven track record in transforming Figma UI/UX designs into modular components, engineering RESTful APIs, and optimizing web performance.",
    academicPerformance: {
      degree: "BCA (Bachelor of Computer Applications)",
      college: "C D Jain College of Commerce",
      location: "Shrirampur, Maharashtra",
      completed: "02/2024",
      tyBca: "9.04 CGPA",
      syBca: "8.86 CGPA",
      fyBca: "8.33 CGPA"
    }
  },
  messages: [] as MessageDocument[]
};

// Seed initial message for demo
db.messages.push({
  _id: 'msg_' + Date.now(),
  name: "Priya Sharma",
  email: "priya.techlead@example.com",
  subject: "Full Stack Developer Role Opportunity",
  message: "Hi Sachin, loved your portfolio and your work on the Electro Next.js platform. We have an exciting MERN stack opening we would love to discuss with you!",
  createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
  read: false
});

// REST API Endpoints
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    stack: 'MERN (MongoDB + Express + React + Node.js)'
  });
});

// Get developer profile
app.get('/api/profile', (req, res) => {
  res.json(db.profile);
});

// Post contact message with email forwarding
app.post('/api/contact', async (req, res) => {
  const { name, email, subject, message } = req.body;

  if (!name || !email || !message) {
    return res.status(400).json({
      success: false,
      error: 'Please provide name, email, and message.'
    });
  }

  // Basic email format check
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({
      success: false,
      error: 'Please provide a valid email address.'
    });
  }

  const cleanName = String(name).trim();
  const cleanEmail = String(email).trim().toLowerCase();
  const cleanSubject = subject ? String(subject).trim() : 'Portfolio Contact Inquiry';
  const cleanMessage = String(message).trim();

  const newMessage: MessageDocument = {
    _id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    name: cleanName,
    email: cleanEmail,
    subject: cleanSubject,
    message: cleanMessage,
    createdAt: new Date().toISOString(),
    read: false
  };

  db.messages.unshift(newMessage);

  // Attempt backend email dispatch
  let emailDispatched = false;
  let emailNotice = '';
  try {
    const emailRes = await fetch('https://formsubmit.co/ajax/yadavsachin7249407392@gmail.com', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Origin': 'https://sachinyadav2002.vercel.app',
        'Referer': 'https://sachinyadav2002.vercel.app/'
      },
      body: JSON.stringify({
        name: cleanName,
        email: cleanEmail,
        _replyto: cleanEmail,
        _subject: `Portfolio Message: ${cleanSubject} (from ${cleanName})`,
        message: `Name: ${cleanName}\nEmail: ${cleanEmail}\nSubject: ${cleanSubject}\n\nMessage:\n${cleanMessage}`,
        _template: 'table',
        _captcha: 'false'
      })
    });
    const emailData = await emailRes.json() as any;
    if (emailRes.ok && (emailData.success === 'true' || emailData.success === true)) {
      emailDispatched = true;
    } else if (emailData.message && emailData.message.includes('Activation')) {
      emailNotice = 'activation_pending';
    }
  } catch (err) {
    console.warn('Backend email dispatch notice:', err);
  }

  res.status(201).json({
    success: true,
    message: 'Your message was sent successfully to Sachin Yadav!',
    emailDispatched,
    emailNotice,
    data: newMessage
  });
});

// Get received messages (demonstrates real backend persistence)
app.get('/api/contact/messages', (req, res) => {
  res.json({
    success: true,
    count: db.messages.length,
    messages: db.messages
  });
});

// Upload / Update Profile Photo endpoint
app.post('/api/upload-photo', (req, res) => {
  const { imageBase64 } = req.body;
  if (!imageBase64) {
    return res.status(400).json({
      success: false,
      error: 'No image data provided'
    });
  }

  try {
    const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');

    const filesToUpdate = ['sachin-face.jpg', 'sachin-face.png', 'sachin-photo.png', 'sachin-face-crop.jpg', 'sachin-face-circle.png'];
    for (const fname of filesToUpdate) {
      fs.writeFileSync(path.join(process.cwd(), 'public', fname), buffer);
      const distPath = path.join(process.cwd(), 'dist', fname);
      if (fs.existsSync(path.join(process.cwd(), 'dist'))) {
        fs.writeFileSync(distPath, buffer);
      }
    }

    res.json({
      success: true,
      message: 'Profile photo updated successfully',
      timestamp: Date.now()
    });
  } catch (err: any) {
    console.error('Failed to write photo:', err);
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
});

// Download Project ZIP endpoint
app.get('/api/project/download-zip', (req, res) => {
  const zipFile = path.join(process.cwd(), 'public', 'portfolio-sachin-yadav.zip');
  if (fs.existsSync(zipFile)) {
    res.download(zipFile, 'sachin-yadav-portfolio.zip');
  } else {
    res.status(404).send('ZIP file not found');
  }
});

// Helper to retrieve authentic resume PDF buffer across environments
function getResumePdfBuffer(): Buffer {
  const possiblePaths = [
    path.join(process.cwd(), 'public', 'Sachin_Yadav_Resume.pdf'),
    path.join(process.cwd(), 'dist', 'Sachin_Yadav_Resume.pdf'),
    path.resolve('public', 'Sachin_Yadav_Resume.pdf'),
    path.resolve('dist', 'Sachin_Yadav_Resume.pdf'),
  ];
  for (const p of possiblePaths) {
    if (fs.existsSync(p)) {
      return fs.readFileSync(p);
    }
  }
  return Buffer.from(RESUME_PDF_BASE64, 'base64');
}

// Download Resume endpoint (serves official binary PDF)
app.get('/api/resume/download', (req, res) => {
  const buffer = getResumePdfBuffer();
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'attachment; filename="Sachin_Yadav_Resume.pdf"');
  res.setHeader('Content-Length', buffer.length.toString());
  res.setHeader('Cache-Control', 'public, max-age=3600');
  return res.end(buffer);
});

// View Resume inline endpoint (for opening directly in browser/mobile tab)
app.get('/api/resume/view', (req, res) => {
  const buffer = getResumePdfBuffer();
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'inline; filename="Sachin_Yadav_Resume.pdf"');
  res.setHeader('Content-Length', buffer.length.toString());
  res.setHeader('Cache-Control', 'public, max-age=3600');
  return res.end(buffer);
});

// Vite middleware / production serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MERN Stack Portfolio server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
